package com.rathor.hci.adapter;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.rathor.hci.R;

import java.util.HashMap;


/**
 * Created by gigabyte on 06-12-2016.
 */

public class CustomGridAdapter extends BaseAdapter {
    private Context mContext;
    private final String[] web;
    private final int[] Imageid;
    public HashMap<Integer, Boolean> mSelectedList = new HashMap<>();
    private int mSelectedCount = 0;

    public CustomGridAdapter(Context c, String[] web, int[] Imageid) {
        mContext = c;
        this.Imageid = Imageid;
        this.web = web;
        for (int i = 0; i < web.length; i++) {
            mSelectedList.put(i, false);
        }
    }

    @Override
    public int getCount() {
        // TODO Auto-generated method stub
        return web.length;
    }

    @Override
    public Object getItem(int position) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long getItemId(int position) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        // TODO Auto-generated method stub
        View grid;
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        grid = inflater.inflate(R.layout.grid_single, null);
        TextView textView = (TextView) grid.findViewById(R.id.grid_text);
        final ImageView imageView = (ImageView) grid.findViewById(R.id.grid_image);
        textView.setText(web[position]);
        imageView.setImageResource(Imageid[position]);

        if (mSelectedList.get(position) == true) {
            imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.toolbar_color));
        } else {
            imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.tranparent_color));
        }

        grid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mSelectedList.get(position) == true) {
                    mSelectedList.put(position, false);
                    mSelectedCount = mSelectedCount + 1;
                    imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.light_yellow));
                } else {
                    imageView.setBackgroundColor(ContextCompat.getColor(mContext, R.color.tranparent_color));
                    mSelectedList.put(position, true);
                    mSelectedCount = mSelectedCount -1;
                }

                notifyDataSetChanged();
               /* for (int i = 0; i < mSelectedList.size(); i++) {
                    if (mSelectedList.get(i) == true)
                        mSelectedCount = mSelectedCount + 1;
                }

                if (mSelectedCount >5){
                    Toast.makeText(mContext, "You can not select more than 5 intersets", Toast.LENGTH_SHORT).show();
                }*/

            }


        });

        return grid;
    }


}